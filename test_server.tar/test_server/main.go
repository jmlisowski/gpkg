package main

import (
	"fmt"
	"log"
	"net/http"
)

// make a server using the http package on port 8080

func main() {
	// create a file server
	fs := http.FileServer(http.Dir("."))
	// tell the user the server is running
	fmt.Println("Server running on port 8080")
	// check for any errors
	if err := http.ListenAndServe(":8080", fs); err != nil {
		log.Fatal(err)
	}
}
