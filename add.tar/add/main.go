package main

import (
	"os"
	"strconv"
)

func main() {
	args := os.Args[1:]
	arg1, err1 := strconv.Atoi(args[0])
	arg2, err2 := strconv.Atoi(args[1])
	if err1 != nil {
		panic(err1)
	}
	if err2 != nil {
		panic(err2)
	}
	println(arg1 + arg2)
}
